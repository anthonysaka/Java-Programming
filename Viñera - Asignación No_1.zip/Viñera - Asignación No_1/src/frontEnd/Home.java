package frontEnd;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import backEnd.Warehouse;
import java.awt.Cursor;

public class Home extends JFrame {

	private Warehouse myWarehouse;

	private JPanel backgroundPane;
	private JPanel panelLeft;
	private JLabel lblBgLfPanel;
	private JLabel lblLogoIcon;

	private Dimension dimention;
	private JButton btnAddWine;
	private JButton btnAddSuppli;
	private JButton btnListWine;
	private JButton btnListSuppli;
	private JLabel lblWines;
	private JSeparator separator;
	private JSeparator separatorMenu;
	private JLabel lblSuppliers;
	private JButton btnClose;
	private JLabel lblSales;
	private JSeparator separator_1;
	private JButton btnSalesManager;
	private JButton btnSell;

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Warehouse warehouse = new Warehouse();
					Home frame = new Home(warehouse);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home(Warehouse warehouse) { 
		this.myWarehouse = warehouse;
		
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1455, 740);
		dimention = super.getToolkit().getScreenSize();
		super.setSize(dimention.width, (dimention.height-50));
		setLocationRelativeTo(null);

		backgroundPane = new JPanel();
		backgroundPane.setBackground(Color.BLACK);
		backgroundPane.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		setContentPane(backgroundPane);
		backgroundPane.setLayout(null);

		panelLeft = new JPanel();
		panelLeft.setBounds(0, 0, 465, 1030);
		panelLeft.setAlignmentY(Component.TOP_ALIGNMENT);
		panelLeft.setAlignmentX(Component.LEFT_ALIGNMENT);
		backgroundPane.add(panelLeft);
		panelLeft.setLayout(null);
		/*********************************/	
		lblLogoIcon = new JLabel();
		lblLogoIcon.setBounds(49, 24, 366, 372);
		panelLeft.add(lblLogoIcon);
		/** to adjust image at size of JLabel **/
		ImageIcon logo = new ImageIcon(getClass().getResource("/frontEnd/images/logo_transparent.png"));
		Icon iconLogo = new ImageIcon(logo.getImage().getScaledInstance(lblLogoIcon.getWidth(), lblLogoIcon.getHeight(), Image.SCALE_SMOOTH));
		lblLogoIcon.setIcon(iconLogo);
		/*********************************/	
		/** to adjust image at size of JLabel **/
		ImageIcon bgMenu = new ImageIcon(getClass().getResource("/frontEnd/images/wine_barril.png"));

		btnAddSuppli = new JButton("Add supplier");
		btnAddSuppli.setForeground(new Color(255, 255, 240));
		btnAddSuppli.setFont(new Font("Consolas", Font.BOLD, 26));
		btnAddSuppli.setHorizontalAlignment(SwingConstants.LEADING);
		btnAddSuppli.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnAddSuppli.setIconTextGap(30);
		btnAddSuppli.setBorder(null);
		btnAddSuppli.setBackground(Color.BLACK);
		btnAddSuppli.setIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_add_48px.png")));
		btnAddSuppli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddSupplier supplier = new AddSupplier(myWarehouse,null);
				btnAddWine.setEnabled(false);
				btnListWine.setEnabled(false);
				btnListSuppli.setEnabled(false);
				btnSalesManager.setEnabled(false);
				btnSell.setEnabled(false);
				btnClose.setEnabled(false);
				
				
				supplier.setModal(true);
				supplier.setVisible(true);
				
				btnAddWine.setEnabled(true);
				btnListWine.setEnabled(true);
				btnListSuppli.setEnabled(true);
				btnSalesManager.setEnabled(true);
				btnSell.setEnabled(true);
				btnClose.setEnabled(true);
			}
		});
		btnAddSuppli.setBounds(49, 882, 366, 53);
		panelLeft.add(btnAddSuppli);

		btnListSuppli = new JButton("List suppliers");
		btnListSuppli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListSuppliers listSuppli = new ListSuppliers(myWarehouse);
				btnAddWine.setEnabled(false);
				btnAddSuppli.setEnabled(false);
				btnListSuppli.setEnabled(false);
				btnSalesManager.setEnabled(false);
				btnSell.setEnabled(false);
				btnClose.setEnabled(false);

				listSuppli.setModal(true);
				listSuppli.setVisible(true);

				btnAddWine.setEnabled(true);
				btnAddSuppli.setEnabled(true);
				btnListSuppli.setEnabled(true);
				btnSalesManager.setEnabled(true);
				btnSell.setEnabled(true);
				btnClose.setEnabled(true);

			}
		});
		btnListSuppli.setForeground(new Color(255, 255, 240));
		btnListSuppli.setFont(new Font("Consolas", Font.BOLD, 26));
		btnListSuppli.setHorizontalAlignment(SwingConstants.LEADING);
		btnListSuppli.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnListSuppli.setIconTextGap(30);
		btnListSuppli.setBorder(null);
		btnListSuppli.setBackground(Color.BLACK);
		btnListSuppli.setIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_supplier_48px.png")));
		btnListSuppli.setBounds(49, 948, 366, 53);
		panelLeft.add(btnListSuppli);

		btnAddWine = new JButton("Add wine");
		btnAddWine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddWine wine = new AddWine(myWarehouse, null);
				btnListWine.setEnabled(false);
				btnAddSuppli.setEnabled(false);
				btnListSuppli.setEnabled(false);
				btnSalesManager.setEnabled(false);
				btnSell.setEnabled(false);
				btnClose.setEnabled(false);

				wine.setModal(true);
				wine.setVisible(true);

				btnListWine.setEnabled(true);
				btnAddSuppli.setEnabled(true);
				btnListSuppli.setEnabled(true);
				btnSalesManager.setEnabled(true);
				btnSell.setEnabled(true);
				btnClose.setEnabled(true);

			}
		});
		btnAddWine.setAlignmentX(Component.CENTER_ALIGNMENT);
		btnAddWine.setForeground(new Color(255, 255, 240));
		btnAddWine.setFont(new Font("Consolas", Font.BOLD, 26));
		btnAddWine.setHorizontalAlignment(SwingConstants.LEADING);
		btnAddWine.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnAddWine.setIconTextGap(30);
		btnAddWine.setBorder(null);
		btnAddWine.setBackground(Color.BLACK);
		btnAddWine.setIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_add_48px.png")));
		btnAddWine.setBounds(49, 676, 366, 53);
		panelLeft.add(btnAddWine);

		btnListWine = new JButton("List wines");
		btnListWine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListWines listWine = new ListWines(myWarehouse);
				btnAddWine.setEnabled(false);
				btnAddSuppli.setEnabled(false);
				btnListSuppli.setEnabled(false);
				btnSalesManager.setEnabled(false);
				btnSell.setEnabled(false);
				btnClose.setEnabled(false);

				listWine.setModal(true);
				listWine.setVisible(true);

				btnAddWine.setEnabled(true);
				btnAddSuppli.setEnabled(true);
				btnListSuppli.setEnabled(true);
				btnSalesManager.setEnabled(true);
				btnSell.setEnabled(true);
				btnClose.setEnabled(true);
				
			}
		});
		btnListWine.setForeground(new Color(255, 255, 240));
		btnListWine.setFont(new Font("Consolas", Font.BOLD, 26));
		btnListWine.setHorizontalAlignment(SwingConstants.LEADING);
		btnListWine.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnListWine.setIconTextGap(30);
		btnListWine.setBorder(null);
		btnListWine.setBackground(Color.BLACK);
		btnListWine.setIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_wine_bottle_48px.png")));
		btnListWine.setBounds(49, 742, 366, 53);
		panelLeft.add(btnListWine);

		separator = new JSeparator();
		separator.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		separator.setOpaque(true);
		separator.setBackground(new Color(0, 0, 0));
		separator.setBounds(49, 655, 366, 8);
		panelLeft.add(separator);

		lblWines = new JLabel("  WINES");
		lblWines.setBackground(new Color(5, 10, 10, 99));
		lblWines.setOpaque(true);
		lblWines.setForeground(Color.WHITE);
		lblWines.setFont(new Font("Consolas", Font.BOLD, 26));
		lblWines.setBounds(49, 620, 366, 37);
		panelLeft.add(lblWines);

		separatorMenu = new JSeparator();
		separatorMenu.setOpaque(true);
		separatorMenu.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		separatorMenu.setBackground(Color.BLACK);
		separatorMenu.setBounds(49, 861, 366, 8);
		panelLeft.add(separatorMenu);

		lblSuppliers = new JLabel("  SUPPLIERS");
		lblSuppliers.setOpaque(true);
		lblSuppliers.setForeground(Color.WHITE);
		lblSuppliers.setFont(new Font("Consolas", Font.BOLD, 26));
		lblSuppliers.setBackground(new Color(5, 10, 10, 99));
		lblSuppliers.setBounds(49, 826, 366, 37);
		panelLeft.add(lblSuppliers);
		
		lblSales = new JLabel("  SALES");
		lblSales.setOpaque(true);
		lblSales.setForeground(Color.WHITE);
		lblSales.setFont(new Font("Consolas", Font.BOLD, 26));
		lblSales.setBackground(new Color(5, 10, 10, 99));
		lblSales.setBounds(49, 410, 366, 37);
		panelLeft.add(lblSales);
		
		separator_1 = new JSeparator();
		separator_1.setOpaque(true);
		separator_1.setBorder(new LineBorder(new Color(0, 0, 0), 8));
		separator_1.setBackground(Color.BLACK);
		separator_1.setBounds(49, 445, 366, 8);
		panelLeft.add(separator_1);
						
						btnSalesManager = new JButton("Manage sales");
						btnSalesManager.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								ManageSales manageSale = new ManageSales(myWarehouse);
								btnAddWine.setEnabled(false);
								btnAddSuppli.setEnabled(false);
								btnListSuppli.setEnabled(false);
								btnListWine.setEnabled(false);
								btnSell.setEnabled(false);
								btnClose.setEnabled(false);

								manageSale.setModal(true);
								manageSale.setVisible(true);

								btnAddWine.setEnabled(true);
								btnAddSuppli.setEnabled(true);
								btnListSuppli.setEnabled(true);
								btnListWine.setEnabled(true);
								btnSell.setEnabled(true);
								btnClose.setEnabled(true);
							}
						});
						btnSalesManager.setIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_total_sales_1_48px.png")));
						btnSalesManager.setIconTextGap(30);
						btnSalesManager.setHorizontalTextPosition(SwingConstants.RIGHT);
						btnSalesManager.setHorizontalAlignment(SwingConstants.LEADING);
						btnSalesManager.setForeground(new Color(255, 255, 240));
						btnSalesManager.setFont(new Font("Consolas", Font.BOLD, 26));
						btnSalesManager.setBorder(null);
						btnSalesManager.setBackground(Color.BLACK);
						btnSalesManager.setAlignmentX(0.5f);
						btnSalesManager.setBounds(49, 466, 366, 53);
						panelLeft.add(btnSalesManager);
						
						btnSell = new JButton("Sell !");
						btnSell.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
								SellWine sell = new SellWine(myWarehouse);
								btnAddWine.setEnabled(false);
								btnAddSuppli.setEnabled(false);
								btnListSuppli.setEnabled(false);
								btnListWine.setEnabled(false);
								btnSalesManager.setEnabled(false);
								btnClose.setEnabled(false);

								sell.setModal(true);
								sell.setVisible(true);

								btnAddWine.setEnabled(true);
								btnAddSuppli.setEnabled(true);
								btnListSuppli.setEnabled(true);
								btnListWine.setEnabled(true);
								btnSell.setEnabled(true);
								btnSalesManager.setEnabled(true);
								btnClose.setEnabled(true);
								
							}
						});
						btnSell.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
						btnSell.setIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_sale_48px_3.png")));
						btnSell.setIconTextGap(30);
						btnSell.setHorizontalTextPosition(SwingConstants.RIGHT);
						btnSell.setHorizontalAlignment(SwingConstants.LEADING);
						btnSell.setForeground(new Color(255, 255, 240));
						btnSell.setFont(new Font("Consolas", Font.BOLD, 26));
						btnSell.setBorder(new LineBorder(Color.RED, 1, true));
						btnSell.setBackground(Color.BLACK);
						btnSell.setBounds(49, 532, 366, 53);
						panelLeft.add(btnSell);
						
								lblBgLfPanel = new JLabel();
								lblBgLfPanel.setBounds(0, 0, 465, 1030);
								panelLeft.add(lblBgLfPanel);
								Icon iconBg = new ImageIcon(bgMenu.getImage().getScaledInstance(lblBgLfPanel.getWidth(), lblBgLfPanel.getHeight(), Image.SCALE_SMOOTH));
								lblBgLfPanel.setIcon(iconBg);
								
										lblBgLfPanel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
										lblBgLfPanel.setAlignmentY(Component.TOP_ALIGNMENT);

		btnClose = new JButton("");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnClose.setPressedIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_close_sign_48px.png")));
		btnClose.setRolloverIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_close_sign_48px.png")));
		btnClose.setIcon(new ImageIcon(Home.class.getResource("/frontEnd/images/icons8_close_window_48px_1.png")));
		btnClose.setPreferredSize(new Dimension(100, 30));
		btnClose.setHideActionText(true);
		btnClose.setForeground(Color.WHITE);
		btnClose.setFont(new Font("Consolas", Font.BOLD, 20));
		btnClose.setBorder(null);
		btnClose.setBackground(Color.BLACK);
		btnClose.setActionCommand("Cancel");
		btnClose.setBounds(1849, 13, 59, 48);
		backgroundPane.add(btnClose);



	}
}
