package frontEnd;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import backEnd.Supplier;
import backEnd.Warehouse;
import backEnd.Wine;


public class AddWine extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JPanel panelBg;
	private JLabel lblCode;
	private JTextField txtCode;
	private JLabel lblName;
	private JTextField txtName;
	private JSpinner spnVinYear;
	private JLabel lblVintageYear;
	private JComboBox cbxType;
	private JLabel lblType;
	private JPanel panel;
	private JLabel lblRealAmount;
	private JLabel lblMinAmount;
	private JLabel lblMaxAmount;
	private JSpinner spnRealAmount;
	private JSpinner spnMinAmount;
	private JSpinner spnMaxAmount;
	private JLabel lblAmounts;
	private JSeparator separator;
	private JComboBox cbxSupplier;
	private JLabel lblSupplier;
	
	private Warehouse myWarehouse;
	private Wine myWine;

	/**
	 * Create the dialog.
	 */
	public AddWine(Warehouse warehouse, Wine wine) {
		this.myWarehouse = warehouse;
		this.myWine = wine;
		
		if (myWine == null) {
			setTitle("Add Suppplier");
		}
		else {
			setTitle("Modify Supplier:  : "+ myWine.getCode() + myWine.getName());
		}

		getContentPane().setBackground(new Color(128, 128, 128));
		setBackground(new Color(255, 250, 250));
		setResizable(false);
		setUndecorated(true);
		setBounds(543, 66, 1300, 900);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 1300, 900);
		contentPanel.setBackground(new Color(20, 10, 15));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);

		panelBg = new JPanel();
		panelBg.setBounds(0, 0, 1300, 900);
		contentPanel.add(panelBg);
		panelBg.setBackground(new Color(0, 0, 0));
		panelBg.setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setBounds(0, 817, 1300, 83);
			panelBg.add(buttonPane);
			buttonPane.setBorder(null);
			buttonPane.setLayout(null);
			{
				JButton okButton = new JButton();
				
				if (myWine == null) {
					okButton.setText("Add");
					okButton.setPressedIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_wine_bottle_48px_1.png")));
					okButton.setRolloverIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_wine_bottle_48px_1.png")));
					okButton.setIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_add_48px_1.png")));
				} 
				else
				{
					okButton.setText("Save");
					okButton.setRolloverIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setPressedIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_save_48px_1.png")));
				}
				
				
				
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String code = txtCode.getText();
						String name = txtName.getText();
						String type = cbxType.getSelectedItem().toString();
						Supplier suppli = myWarehouse.searchSupplierByName(cbxSupplier.getSelectedItem().toString());
						int year = Integer.parseInt(spnVinYear.getValue().toString());
						int realAmount = Integer.parseInt(spnRealAmount.getValue().toString());
						int minAmount = Integer.parseInt(spnMinAmount.getValue().toString());
						int maxAmount = Integer.parseInt(spnMaxAmount.getValue().toString());

						if (myWine == null) {

							
							if (!name.equalsIgnoreCase("") && cbxType.getSelectedIndex()>0 && cbxSupplier.getSelectedIndex()>0 && maxAmount>=1 && minAmount>=1 && realAmount>=1) {
								Wine auxWine = new Wine(name, code, type, year, minAmount, maxAmount, realAmount, suppli);
								myWarehouse.addWine(auxWine);
								JOptionPane.showMessageDialog(null, "Successfully added", "Alert - Did it!", JOptionPane.INFORMATION_MESSAGE);	
								clean();
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Check the fields", "Validate", JOptionPane.WARNING_MESSAGE);
							}
							
						}
						else
						{
							myWine.setCodigo(code);
							myWine.setName(name);
							myWine.setSupplier(suppli);
							myWine.setType(type);
							myWine.setVintageYear(year);
							myWine.setMaxAmount(maxAmount);
							myWine.setMinAmount(minAmount);
							myWine.setRealAmount(realAmount);
							myWarehouse.updateWines(myWine);
							JOptionPane.showMessageDialog(null, "Successfully modified", "Alert - Did it!", JOptionPane.INFORMATION_MESSAGE);
							dispose();
							ListWines.loadTableWine();
						}
						
					}
				});
				
				okButton.setFont(new Font("Consolas", Font.BOLD, 20));
				okButton.setForeground(new Color(255, 255, 255));
				okButton.setOpaque(false);
				okButton.setBackground(new Color(255, 250, 250, 80));
				okButton.setBorder(null);
				okButton.setBounds(778, 8, 186, 48);
				okButton.setPreferredSize(new Dimension(100, 30));
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{

				JButton cancelButton = new JButton("Cancel");
				cancelButton.setRolloverIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setPressedIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setFont(new Font("Consolas", Font.BOLD, 20));
				cancelButton.setForeground(new Color(255, 255, 255));
				cancelButton.setHideActionText(true);
				cancelButton.setBackground(new Color(0, 0, 0));
				cancelButton.setBorder(null);
				cancelButton.setIcon(new ImageIcon(AddWine.class.getResource("/frontEnd/images/icons8_cancel_48px.png")));
				cancelButton.setBounds(1020, 8, 186, 48);
				cancelButton.setPreferredSize(new Dimension(100, 30));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		
		lblCode = new JLabel("Code:");
		lblCode.setHorizontalAlignment(SwingConstants.LEFT);
		lblCode.setForeground(Color.WHITE);
		lblCode.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblCode.setBounds(12, 13, 218, 35);
		panelBg.add(lblCode);
		
		txtCode = new JTextField();
		if (myWine != null) {
			txtCode.setEditable(false);
		}
		txtCode.setEnabled(false);
		txtCode.setDisabledTextColor(Color.BLACK);
		txtCode.setHorizontalAlignment(SwingConstants.CENTER);
		txtCode.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		txtCode.setColumns(10);
		txtCode.setBounds(12, 61, 164, 41);
		txtCode.setEditable(false);
		
		if(myWine==null){
			txtCode.setText("WN-" +(Wine.generateCode));
		}
		
		panelBg.add(txtCode);
		
		lblName = new JLabel("Name:");
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setForeground(Color.WHITE);
		lblName.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblName.setBounds(188, 211, 218, 35);
		panelBg.add(lblName);
		
		txtName = new JTextField();
		txtName.setFont(new Font("Consolas", Font.ITALIC, 20));
		txtName.setColumns(10);
		txtName.setBounds(188, 259, 323, 41);
		panelBg.add(txtName);
		
		spnVinYear = new JSpinner();
		spnVinYear.setModel(new SpinnerNumberModel(new Integer(1850), null, null, new Integer(1)));
		spnVinYear.setFont(new Font("Consolas", Font.ITALIC, 20));
		spnVinYear.setBounds(1023, 259, 218, 41);
		panelBg.add(spnVinYear);
		
		lblVintageYear = new JLabel("Vintage year:");
		lblVintageYear.setHorizontalAlignment(SwingConstants.LEFT);
		lblVintageYear.setForeground(Color.WHITE);
		lblVintageYear.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblVintageYear.setBounds(1023, 211, 218, 35);
		panelBg.add(lblVintageYear);
		
		cbxType = new JComboBox();
		cbxType.setModel(new DefaultComboBoxModel(new String[] {"<select>", "Red Wine", "White Wine", "Merlot", "Pinot Noir", "Ros\u00E9", "Sparkling wine"}));
		cbxType.setFont(new Font("Consolas", Font.ITALIC, 20));
		cbxType.setBounds(655, 259, 218, 41);
		panelBg.add(cbxType);
		
		lblType = new JLabel("Type:");
		lblType.setHorizontalAlignment(SwingConstants.LEFT);
		lblType.setForeground(Color.WHITE);
		lblType.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblType.setBounds(655, 211, 218, 35);
		panelBg.add(lblType);
		
		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		panel.setBackground(Color.BLACK);
		panel.setBounds(188, 472, 1053, 176);
		panelBg.add(panel);
		panel.setLayout(null);
		
		lblRealAmount = new JLabel("Real Amount:");
		lblRealAmount.setBounds(40, 39, 182, 31);
		lblRealAmount.setHorizontalAlignment(SwingConstants.LEFT);
		lblRealAmount.setForeground(Color.WHITE);
		lblRealAmount.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		panel.add(lblRealAmount);
		
		lblMinAmount = new JLabel("Min. Amount:");
		lblMinAmount.setBounds(419, 39, 182, 31);
		lblMinAmount.setHorizontalAlignment(SwingConstants.LEFT);
		lblMinAmount.setForeground(Color.WHITE);
		lblMinAmount.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		panel.add(lblMinAmount);
		
		lblMaxAmount = new JLabel("Max. Amount:");
		lblMaxAmount.setHorizontalAlignment(SwingConstants.LEFT);
		lblMaxAmount.setForeground(Color.WHITE);
		lblMaxAmount.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblMaxAmount.setBounds(799, 39, 182, 31);
		panel.add(lblMaxAmount);
		
		spnRealAmount = new JSpinner();
		spnRealAmount.setFont(new Font("Consolas", Font.ITALIC, 20));
		spnRealAmount.setBounds(40, 83, 218, 41);
		panel.add(spnRealAmount);
		
		spnMinAmount = new JSpinner();
		spnMinAmount.setFont(new Font("Consolas", Font.ITALIC, 20));
		spnMinAmount.setBounds(419, 83, 218, 41);
		panel.add(spnMinAmount);
		
		spnMaxAmount = new JSpinner();
		spnMaxAmount.setFont(new Font("Consolas", Font.ITALIC, 20));
		spnMaxAmount.setBounds(799, 83, 218, 41);
		panel.add(spnMaxAmount);
		
		lblAmounts = new JLabel("  Amounts");
		lblAmounts.setOpaque(true);
		lblAmounts.setForeground(Color.WHITE);
		lblAmounts.setFont(new Font("Consolas", Font.BOLD, 26));
		lblAmounts.setBackground(new Color(240, 240, 240, 99));
		lblAmounts.setBounds(188, 417, 1053, 37);
		panelBg.add(lblAmounts);
		
		separator = new JSeparator();
		separator.setOpaque(true);
		separator.setBorder(new LineBorder(new Color(255, 165, 0), 8));
		separator.setBackground(new Color(255, 165, 0));
		separator.setBounds(188, 451, 1053, 8);
		panelBg.add(separator);
		
		cbxSupplier = new JComboBox();
		cbxSupplier.setFont(new Font("Consolas", Font.ITALIC, 20));
		cbxSupplier.setBounds(1023, 70, 218, 41);
		panelBg.add(cbxSupplier);
		
		lblSupplier = new JLabel("Supplier:");
		lblSupplier.setHorizontalAlignment(SwingConstants.LEFT);
		lblSupplier.setForeground(Color.WHITE);
		lblSupplier.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblSupplier.setBounds(1023, 24, 218, 35);
		panelBg.add(lblSupplier);
		

		

			loadAvailableSuppliers(); //PARA CARGAR LOS SUPLIDORES AL CBXSUPPLIERS
			loadWine();

	}
	
	private void loadWine() {
		if (myWine != null) {
			txtCode.setText(myWine.getCode());
			txtName.setText(myWine.getName());
			cbxType.setSelectedItem(myWine.getType().toString());
			cbxSupplier.setSelectedItem(myWine.getSupplier().getName().toString());
			spnVinYear.setValue(myWine.getVintageYear());
			spnMaxAmount.setValue(myWine.getMaxAmount());
			spnMinAmount.setValue(myWine.getMinAmount());
			spnRealAmount.setValue(myWine.getRealAmount());
		}
		
	}

	private void clean() {
		txtCode.setText("WN-" +(Wine.generateCode));
		txtName.setText("");
		cbxSupplier.setSelectedIndex(0);
		cbxType.setSelectedIndex(0);
		spnRealAmount.setValue(Integer.parseInt("0"));
		spnMinAmount.setValue(Integer.parseInt("0"));
		spnMaxAmount.setValue(Integer.parseInt("0"));
		spnVinYear.setValue(Integer.parseInt("1850"));


	}

	private void loadAvailableSuppliers() {//PARA CARGAR LOS SUPLIDORES AL CBXSUPPLIERS
		cbxSupplier.removeAllItems();
		
		for (int i = 0; i < myWarehouse.getAmountSupplier() ; i++) {
			cbxSupplier.addItem(new String(myWarehouse.getListSupplier()[i].getName()));
		}
		cbxSupplier.insertItemAt(new String("<Select>"), 0);
		cbxSupplier.setSelectedIndex(0);
		
	}
	
	
}
