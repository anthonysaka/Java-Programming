package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import backEnd.Warehouse;
import backEnd.Wine;

public class ListSalesYear extends JDialog {

	private final JPanel contentPanel = new JPanel();


	private static DefaultTableModel model;
	private JPanel panelBg;
	private JScrollPane scrollPane;
	private static Object[] column;
	private JButton btnModify;
	
	private static Warehouse myWarehouse;
	private String codeWine;
	private String nameWine;
	private  static JTable tableSalesWine;



	/**
	 * Create the dialog.
	 */
	public ListSalesYear(Warehouse warehouse) {
		this.myWarehouse = warehouse;
		getContentPane().setBackground(new Color(128, 128, 128));
		setBackground(new Color(255, 250, 250));
		setResizable(false);
		setUndecorated(true);
		setBounds(543, 66, 1300, 900);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 1300, 900);
		contentPanel.setBackground(new Color(20, 10, 15));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);

		panelBg = new JPanel();
		panelBg.setBounds(0, 0, 1300, 900);
		contentPanel.add(panelBg);
		panelBg.setBackground(new Color(0, 0, 0));
		panelBg.setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setBounds(0, 817, 1300, 83);
			panelBg.add(buttonPane);
			buttonPane.setBorder(null);
			buttonPane.setLayout(null);
			{

				JButton cancelButton = new JButton("Cancel");
				cancelButton.setRolloverIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setPressedIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setFont(new Font("Consolas", Font.BOLD, 20));
				cancelButton.setForeground(new Color(255, 255, 255));
				cancelButton.setHideActionText(true);
				cancelButton.setBackground(new Color(0, 0, 0));
				cancelButton.setBorder(null);
				cancelButton.setIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_48px.png")));
				cancelButton.setBounds(1020, 8, 186, 48);
				cancelButton.setPreferredSize(new Dimension(100, 30));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}

			btnModify = new JButton("Modify");
			btnModify.setAlignmentX(Component.CENTER_ALIGNMENT);
			btnModify.setEnabled(false);
			btnModify.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Wine auxWine = myWarehouse.searchWineByCode(codeWine);
					AddWine wineAdd = new AddWine(myWarehouse, auxWine);
					wineAdd.setModal(true);
					wineAdd.setVisible(true);
				}
			});
			btnModify.setRolloverIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_edit_property_48px.png")));
			btnModify.setPressedIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_edit_property_48px.png")));
			btnModify.setIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_edit_48px.png")));
			btnModify.setPreferredSize(new Dimension(100, 30));
			btnModify.setOpaque(false);
			btnModify.setForeground(Color.WHITE);
			btnModify.setFont(new Font("Consolas", Font.BOLD, 20));
			btnModify.setBorder(null);
			btnModify.setBackground(new Color(255, 250, 250, 80));
			btnModify.setActionCommand("OK");
			btnModify.setBounds(624, 8, 186, 48);
			buttonPane.add(btnModify);
		}

		scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 1276, 791);
		panelBg.add(scrollPane);
		
		tableSalesWine = new JTable();
		tableSalesWine.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Code", "Name", "1 year", "2 year", "3 year", "4 year", "5 year", "6 year", "7 year", "8 year", "9 year", "10 year"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Object.class, Integer.class, Integer.class, Integer.class, Integer.class, Integer.class, Integer.class, Integer.class, Integer.class, Integer.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableSalesWine.getColumnModel().getColumn(0).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(1).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(2).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(3).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(4).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(5).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(6).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(7).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(8).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(9).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(10).setResizable(false);
		tableSalesWine.getColumnModel().getColumn(11).setResizable(false);
		scrollPane.setViewportView(tableSalesWine);
		
		loadTableSales();


	}
	
	/* FUNCTIONS */
	public static void loadTableSales() {
		model = (DefaultTableModel) tableSalesWine.getModel();
		model.setRowCount(0);
		column = new Object[model.getColumnCount()];

		for (int i = 0; i < myWarehouse.getAmountWine(); i++) {
			column[0] = myWarehouse.getListWine()[i].getCode();
			column[1] = myWarehouse.getListWine()[i].getName();
			column[2] = myWarehouse.getListWine()[i].getSalesPerYear()[0];
			column[3] = myWarehouse.getListWine()[i].getSalesPerYear()[1];
			column[4] = myWarehouse.getListWine()[i].getSalesPerYear()[2];
			column[5] = myWarehouse.getListWine()[i].getSalesPerYear()[3];
			column[6] = myWarehouse.getListWine()[i].getSalesPerYear()[4];
			column[7] = myWarehouse.getListWine()[i].getSalesPerYear()[5];
			column[8] = myWarehouse.getListWine()[i].getSalesPerYear()[6];
			column[9] = myWarehouse.getListWine()[i].getSalesPerYear()[7];
			column[10] = myWarehouse.getListWine()[i].getSalesPerYear()[8];
			column[11] = myWarehouse.getListWine()[i].getSalesPerYear()[9];
			model.addRow(column);
		}

	}
}