package frontEnd;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import backEnd.Supplier;
import backEnd.Warehouse;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import javax.swing.SwingConstants;
import java.awt.Dimension;
import javax.swing.ImageIcon;


public class AddSupplier extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JLabel lblName;
	private JLabel lblCountry;
	private JTextField txtName;
	private JLabel lblDeliveryTime;
	private JComboBox cbxCountry;
	private JSpinner spnTime;
	private JPanel panelBg;

	private Warehouse myWarehouse;
	private Supplier mySuppli = null;

	/**
	 * Create the dialog.
	 */
	public AddSupplier(Warehouse warehouse, Supplier suppli) {
		this.myWarehouse = warehouse;
		this.mySuppli = suppli;
		
		if (mySuppli == null) {
			setTitle("Add Suppplier");
		}
		else {
			setTitle("Modify Supplier: "+ mySuppli.getName());
		}

		getContentPane().setBackground(new Color(128, 128, 128));
		setBackground(new Color(255, 250, 250));
		setResizable(false);
		setUndecorated(true);
		setBounds(543, 66, 1300, 900);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 1300, 900);
		contentPanel.setBackground(new Color(20, 10, 15));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);

		panelBg = new JPanel();
		panelBg.setBounds(0, 0, 1300, 900);
		contentPanel.add(panelBg);
		panelBg.setBackground(new Color(0, 0, 0));
		panelBg.setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setBounds(0, 817, 1300, 83);
			panelBg.add(buttonPane);
			buttonPane.setBorder(null);
			buttonPane.setLayout(null);
			{
				JButton okButton = new JButton();
				
				if (mySuppli == null) {
					okButton.setText("Add");
					okButton.setPressedIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_supplier_48px_1.png")));
					okButton.setRolloverIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_supplier_48px_1.png")));
					okButton.setIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_add_48px_1.png")));
				} 
				else
				{
					okButton.setText("Save");
					okButton.setRolloverIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setPressedIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_save_48px_1.png")));
				}
				
			
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (mySuppli == null) {
							String name = txtName.getText();
							String country = cbxCountry.getSelectedItem().toString();
							int time = Integer.parseInt(spnTime.getValue().toString());

							if (!name.equalsIgnoreCase("") && cbxCountry.getSelectedIndex()>0 && time >=1) {
								Supplier auxSuppli = new Supplier(name, country, time);
								myWarehouse.addSupplier(auxSuppli);
								JOptionPane.showMessageDialog(null, "Successfully added", "Alert - Did it!", JOptionPane.INFORMATION_MESSAGE);	
								clean();
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Check the fields", "Validate", JOptionPane.WARNING_MESSAGE);
							}
							
						} 
						else 
						{
							mySuppli.setCountry(cbxCountry.getSelectedItem().toString());
							mySuppli.setTimeDelivery(Integer.parseInt(spnTime.getValue().toString()));
							myWarehouse.updateSuppliers(mySuppli);
							JOptionPane.showMessageDialog(null, "Successfully modified", "Alert - Did it!", JOptionPane.INFORMATION_MESSAGE);
							dispose();
							ListSuppliers.loadTableSuppli();

						}
						
					}
				});

				okButton.setFont(new Font("Consolas", Font.BOLD, 20));
				okButton.setForeground(new Color(255, 255, 255));
				okButton.setOpaque(false);
				okButton.setBackground(new Color(255, 250, 250, 80));
				okButton.setBorder(null);
				okButton.setBounds(778, 8, 186, 48);
				okButton.setPreferredSize(new Dimension(100, 30));
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{

				JButton cancelButton = new JButton("Cancel");
				cancelButton.setRolloverIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setPressedIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setFont(new Font("Consolas", Font.BOLD, 20));
				cancelButton.setForeground(new Color(255, 255, 255));
				cancelButton.setHideActionText(true);
				cancelButton.setBackground(new Color(0, 0, 0));
				cancelButton.setBorder(null);
				cancelButton.setIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_48px.png")));
				cancelButton.setBounds(1020, 8, 186, 48);
				cancelButton.setPreferredSize(new Dimension(100, 30));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}

		lblCountry = new JLabel("Country:");
		lblCountry.setHorizontalAlignment(SwingConstants.LEFT);
		lblCountry.setBounds(482, 300, 335, 35);
		panelBg.add(lblCountry);
		lblCountry.setForeground(new Color(255, 255, 255));
		lblCountry.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));

		lblName = new JLabel("Name:");
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setBounds(482, 138, 335, 35);
		panelBg.add(lblName);
		lblName.setForeground(new Color(255, 255, 255));
		lblName.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));

		txtName = new JTextField();
		if (mySuppli == null) {
			txtName.setEditable(true);
		} 
		else
		{
			txtName.setEditable(false);

		}
		txtName.setBounds(482, 186, 335, 41);
		panelBg.add(txtName);
		txtName.setFont(new Font("Consolas", Font.ITALIC, 20));
		txtName.setColumns(10);

		cbxCountry = new JComboBox();
		cbxCountry.setBounds(482, 348, 335, 41);
		panelBg.add(cbxCountry);
		cbxCountry.setFont(new Font("Consolas", Font.ITALIC, 20));
		cbxCountry.setModel(new DefaultComboBoxModel(new String[] {"<Select>", "Chile", "Spain", "Dominican Republic", "France", "Italy", "Portugal"}));

		lblDeliveryTime = new JLabel("Delivery Time:");
		lblDeliveryTime.setHorizontalAlignment(SwingConstants.LEFT);
		lblDeliveryTime.setBounds(482, 465, 335, 35);
		panelBg.add(lblDeliveryTime);
		lblDeliveryTime.setForeground(new Color(255, 255, 255));
		lblDeliveryTime.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));

		spnTime = new JSpinner();
		spnTime.setBounds(482, 513, 335, 41);
		panelBg.add(spnTime);
		spnTime.setFont(new Font("Consolas", Font.ITALIC, 20));
		spnTime.setModel(new SpinnerNumberModel(0, 0, 90, 1));
		
		loadSupplier();
	}

	private void loadSupplier() {
		
	if (mySuppli != null) {
		txtName.setText(mySuppli.getName());
		cbxCountry.setSelectedItem(mySuppli.getCountry().toString());
		spnTime.setValue(mySuppli.getTimeDelivery());
		
		}	
	}

	private void clean() {
		txtName.setText("");
		cbxCountry.setSelectedIndex(0);
		spnTime.setValue(Integer.parseInt("0"));

	}
}
