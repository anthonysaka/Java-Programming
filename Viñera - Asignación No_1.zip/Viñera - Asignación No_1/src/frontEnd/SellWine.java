package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import backEnd.Warehouse;
import backEnd.Wine;
import javax.swing.border.EtchedBorder;

public class SellWine extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JPanel panelBg;
	private JPanel panel;
	private JLabel lblSell;
	private JSeparator separator;

	private JLabel lblMake;
	private JLabel lblSelectWine;
	private JComboBox cbxSelectWines;

	private Warehouse myWarehouse;
	private Wine myWine;
	private JTextField txtCodeWine;
	private JButton btnSelect;
	private JLabel lblYear;
	private JLabel label;
	private JLabel label_1;
	private JLabel label_2;
	private JLabel label_3;
	private JLabel label_4;
	private JLabel label_5;
	private JLabel label_6;
	private JLabel label_7;
	private JLabel label_8;
	private JLabel label_9;
	private JTextField txt1;
	private JTextField txt2;
	private JTextField txt3;
	private JTextField txt4;
	private JTextField txt5;
	private JTextField txt6;
	private JTextField txt7;
	private JTextField txt8;
	private JTextField txt9;
	private JTextField txt10;
	private JSeparator separator_1;

	/**
	 * Create the dialog.
	 */
	public SellWine(Warehouse warehouse) {
		this.myWarehouse = warehouse;


		getContentPane().setBackground(new Color(128, 128, 128));
		setBackground(new Color(255, 250, 250));
		setResizable(false);
		setUndecorated(true);
		setBounds(543, 66, 1300, 900);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 1300, 900);
		contentPanel.setBackground(new Color(20, 10, 15));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);

		panelBg = new JPanel();
		panelBg.setBounds(0, 0, 1300, 900);
		contentPanel.add(panelBg);
		panelBg.setBackground(new Color(0, 0, 0));
		panelBg.setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setBounds(0, 817, 1300, 83);
			panelBg.add(buttonPane);
			buttonPane.setBorder(null);
			buttonPane.setLayout(null);
			{
				JButton okButton = new JButton();
		

				if (myWine == null) {
					okButton.setText("Add");
					okButton.setPressedIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_wine_bottle_48px_1.png")));
					okButton.setRolloverIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_wine_bottle_48px_1.png")));
					okButton.setIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_add_48px_1.png")));
				} 
				else
				{
					okButton.setText("Save");
					okButton.setRolloverIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setPressedIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_save_48px_1.png")));
				}



				okButton.setFont(new Font("Consolas", Font.BOLD, 20));
				okButton.setForeground(new Color(255, 255, 255));
				okButton.setOpaque(false);
				okButton.setBackground(new Color(255, 250, 250, 80));
				okButton.setBorder(null);
				okButton.setBounds(778, 8, 186, 48);
				okButton.setPreferredSize(new Dimension(100, 30));
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{

				JButton cancelButton = new JButton("Cancel");
				cancelButton.setRolloverIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setPressedIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setFont(new Font("Consolas", Font.BOLD, 20));
				cancelButton.setForeground(new Color(255, 255, 255));
				cancelButton.setHideActionText(true);
				cancelButton.setBackground(new Color(0, 0, 0));
				cancelButton.setBorder(null);
				cancelButton.setIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_cancel_48px.png")));
				cancelButton.setBounds(1020, 8, 186, 48);
				cancelButton.setPreferredSize(new Dimension(100, 30));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}

		panel = new JPanel();
		panel.setVisible(false);
		panel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		panel.setBackground(Color.BLACK);
		panel.setBounds(125, 294, 1053, 510);
		panelBg.add(panel);
		panel.setLayout(null);
		
		lblYear = new JLabel("Sales per year:");
		lblYear.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear.setForeground(Color.WHITE);
		lblYear.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		lblYear.setBounds(51, 13, 165, 31);
		panel.add(lblYear);
		
		label = new JLabel("1:");
		label.setHorizontalAlignment(SwingConstants.LEFT);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label.setBounds(12, 61, 39, 31);
		panel.add(label);
		
		label_1 = new JLabel("2:");
		label_1.setHorizontalAlignment(SwingConstants.LEFT);
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_1.setBounds(12, 105, 39, 31);
		panel.add(label_1);
		
		label_2 = new JLabel("3:");
		label_2.setHorizontalAlignment(SwingConstants.LEFT);
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_2.setBounds(12, 149, 39, 31);
		panel.add(label_2);
		
		label_3 = new JLabel("4:");
		label_3.setHorizontalAlignment(SwingConstants.LEFT);
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_3.setBounds(12, 193, 39, 31);
		panel.add(label_3);
		
		label_4 = new JLabel("5:");
		label_4.setHorizontalAlignment(SwingConstants.LEFT);
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_4.setBounds(12, 241, 39, 31);
		panel.add(label_4);
		
		label_5 = new JLabel("6:");
		label_5.setHorizontalAlignment(SwingConstants.LEFT);
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_5.setBounds(12, 285, 39, 31);
		panel.add(label_5);
		
		label_6 = new JLabel("7:");
		label_6.setHorizontalAlignment(SwingConstants.LEFT);
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_6.setBounds(12, 329, 39, 31);
		panel.add(label_6);
		
		label_7 = new JLabel("8:");
		label_7.setHorizontalAlignment(SwingConstants.LEFT);
		label_7.setForeground(Color.WHITE);
		label_7.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_7.setBounds(12, 373, 39, 31);
		panel.add(label_7);
		
		label_8 = new JLabel("9:");
		label_8.setHorizontalAlignment(SwingConstants.LEFT);
		label_8.setForeground(Color.WHITE);
		label_8.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_8.setBounds(12, 417, 39, 31);
		panel.add(label_8);
		
		label_9 = new JLabel("10:");
		label_9.setHorizontalAlignment(SwingConstants.LEFT);
		label_9.setForeground(Color.WHITE);
		label_9.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 20));
		label_9.setBounds(12, 461, 39, 31);
		panel.add(label_9);
		
		txt1 = new JTextField();
		txt1.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt1.setEnabled(false);
		txt1.setEditable(false);
		txt1.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt1.setColumns(10);
		txt1.setBounds(63, 61, 153, 31);
		panel.add(txt1);
		
		txt2 = new JTextField();
		txt2.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt2.setEnabled(false);
		txt2.setEditable(false);
		txt2.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt2.setColumns(10);
		txt2.setBounds(63, 105, 153, 31);
		panel.add(txt2);
		
		txt3 = new JTextField();
		txt3.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt3.setEnabled(false);
		txt3.setEditable(false);
		txt3.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt3.setColumns(10);
		txt3.setBounds(63, 149, 153, 31);
		panel.add(txt3);
		
		txt4 = new JTextField();
		txt4.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt4.setEnabled(false);
		txt4.setEditable(false);
		txt4.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt4.setColumns(10);
		txt4.setBounds(63, 193, 153, 31);
		panel.add(txt4);
		
		txt5 = new JTextField();
		txt5.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt5.setEnabled(false);
		txt5.setEditable(false);
		txt5.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt5.setColumns(10);
		txt5.setBounds(63, 241, 153, 31);
		panel.add(txt5);
		
		txt6 = new JTextField();
		txt6.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt6.setEnabled(false);
		txt6.setEditable(false);
		txt6.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt6.setColumns(10);
		txt6.setBounds(63, 285, 153, 31);
		panel.add(txt6);
		
		txt7 = new JTextField();
		txt7.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt7.setEnabled(false);
		txt7.setEditable(false);
		txt7.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt7.setColumns(10);
		txt7.setBounds(63, 329, 153, 31);
		panel.add(txt7);
		
		txt8 = new JTextField();
		txt8.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt8.setEnabled(false);
		txt8.setEditable(false);
		txt8.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt8.setColumns(10);
		txt8.setBounds(63, 373, 153, 31);
		panel.add(txt8);
		
		txt9 = new JTextField();
		txt9.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt9.setEnabled(false);
		txt9.setEditable(false);
		txt9.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt9.setColumns(10);
		txt9.setBounds(63, 417, 153, 31);
		panel.add(txt9);
		
		txt10 = new JTextField();
		txt10.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		txt10.setEnabled(false);
		txt10.setEditable(false);
		txt10.setFont(new Font("Consolas", Font.ITALIC, 20));
		txt10.setColumns(10);
		txt10.setBounds(63, 461, 153, 31);
		panel.add(txt10);
		
		separator_1 = new JSeparator();
		separator_1.setOpaque(true);
		separator_1.setBorder(new LineBorder(new Color(255, 165, 0), 8));
		separator_1.setBackground(new Color(255, 165, 0));
		separator_1.setBounds(273, 13, 6, 479);
		panel.add(separator_1);

		lblSell = new JLabel("  Sell:");
		lblSell.setOpaque(true);
		lblSell.setForeground(Color.WHITE);
		lblSell.setFont(new Font("Consolas", Font.BOLD, 26));
		lblSell.setBackground(new Color(240, 240, 240, 99));
		lblSell.setBounds(125, 239, 1053, 37);
		panelBg.add(lblSell);

		separator = new JSeparator();
		separator.setOpaque(true);
		separator.setBorder(new LineBorder(new Color(255, 165, 0), 8));
		separator.setBackground(new Color(255, 165, 0));
		separator.setBounds(125, 273, 1053, 8);
		panelBg.add(separator);

		lblMake = new JLabel("Make an order of WINE");
		lblMake.setHorizontalAlignment(SwingConstants.LEFT);
		lblMake.setForeground(Color.WHITE);
		lblMake.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 34));
		lblMake.setBounds(451, 86, 399, 31);
		panelBg.add(lblMake);

		lblSelectWine = new JLabel("- Select wine:");
		lblSelectWine.setHorizontalAlignment(SwingConstants.LEFT);
		lblSelectWine.setForeground(Color.WHITE);
		lblSelectWine.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblSelectWine.setBounds(135, 173, 196, 31);
		panelBg.add(lblSelectWine);

		cbxSelectWines = new JComboBox();
		cbxSelectWines.setFont(new Font("Consolas", Font.ITALIC, 20));
		cbxSelectWines.setBounds(343, 173, 312, 31);
		panelBg.add(cbxSelectWines);

		txtCodeWine = new JTextField();
		txtCodeWine.setEditable(false);
		txtCodeWine.setFont(new Font("Consolas", Font.ITALIC, 20));
		txtCodeWine.setColumns(10);
		txtCodeWine.setBounds(712, 173, 220, 31);
		panelBg.add(txtCodeWine);

		btnSelect = new JButton();
		btnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String codeWineSelect = myWarehouse.searchCodeByNameWine(cbxSelectWines.getSelectedItem().toString());
				txtCodeWine.setText(codeWineSelect);
				panel.setVisible(true);
			}
		});
		btnSelect.setIcon(new ImageIcon(SellWine.class.getResource("/frontEnd/images/icons8_wine_glass_36px.png")));
		btnSelect.setText("Select");
		btnSelect.setPreferredSize(new Dimension(100, 30));
		btnSelect.setForeground(Color.BLACK);
		btnSelect.setFont(new Font("Consolas", Font.BOLD, 20));
		btnSelect.setBorder(null);
		btnSelect.setBackground(new Color(255, 140, 0));
		btnSelect.setActionCommand("OK");
		btnSelect.setBounds(992, 159, 147, 45);
		panelBg.add(btnSelect);

		loadAvailableWines();

	}



	private void loadAvailableWines() {//PARA CARGAR LOS VINOS AL CBXWINES
		cbxSelectWines.removeAllItems();

		for (int i = 0; i < myWarehouse.getAmountWine() ; i++) {
			cbxSelectWines.addItem(new String(myWarehouse.getListWine()[i].getName()));
		}
		cbxSelectWines.insertItemAt(new String("<Select>"), 0);
		cbxSelectWines.setSelectedIndex(0);

	}
	
	private void loadSales() {
		String codeWineSelect = myWarehouse.searchCodeByNameWine(cbxSelectWines.getSelectedItem().toString());
		Wine auxWine = myWarehouse.searchWineByCode(codeWineSelect);
		
		txt1.setText(Integer.toString(auxWine.getSalesPerYear()[0]));
		txt2.setText(Integer.toString(auxWine.getSalesPerYear()[1]));
		txt3.setText(Integer.toString(auxWine.getSalesPerYear()[2]));
		txt4.setText(Integer.toString(auxWine.getSalesPerYear()[3]));
		txt5.setText(Integer.toString(auxWine.getSalesPerYear()[4]));
		txt6.setText(Integer.toString(auxWine.getSalesPerYear()[5]));
		txt7.setText(Integer.toString(auxWine.getSalesPerYear()[6]));
		txt8.setText(Integer.toString(auxWine.getSalesPerYear()[7]));
		txt9.setText(Integer.toString(auxWine.getSalesPerYear()[8]));
		txt10.setText(Integer.toString(auxWine.getSalesPerYear()[9]));
		
		
	}
}