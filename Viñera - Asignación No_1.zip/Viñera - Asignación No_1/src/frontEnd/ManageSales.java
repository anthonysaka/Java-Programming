package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import backEnd.Supplier;
import backEnd.Warehouse;
import backEnd.Wine;
import javax.swing.JFormattedTextField;

public class ManageSales extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JPanel panelBg;

	private JLabel lblManage;
	private JButton btnInsertIncomePer;
	private JButton btnSalesPerYear;
	private JLabel lblInsert;
	private JLabel lblViewTable;

	private Warehouse myWarehouse;
	private Wine myWine;

	/**
	 * Create the dialog.
	 */
	public ManageSales(Warehouse warehouse) {
		this.myWarehouse = warehouse;
		


		getContentPane().setBackground(new Color(128, 128, 128));
		setBackground(new Color(255, 250, 250));
		setResizable(false);
		setUndecorated(true);
		setBounds(543, 66, 1300, 900);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 1300, 900);
		contentPanel.setBackground(new Color(20, 10, 15));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);

		panelBg = new JPanel();
		panelBg.setBounds(0, 0, 1300, 900);
		contentPanel.add(panelBg);
		panelBg.setBackground(new Color(0, 0, 0));
		panelBg.setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setBounds(0, 817, 1300, 83);
			panelBg.add(buttonPane);
			buttonPane.setBorder(null);
			buttonPane.setLayout(null);

			{

				JButton cancelButton = new JButton("Cancel");
				cancelButton.setRolloverIcon(new ImageIcon(ManageSales.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setPressedIcon(new ImageIcon(ManageSales.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setFont(new Font("Consolas", Font.BOLD, 20));
				cancelButton.setForeground(new Color(255, 255, 255));
				cancelButton.setHideActionText(true);
				cancelButton.setBackground(new Color(0, 0, 0));
				cancelButton.setBorder(null);
				cancelButton.setIcon(new ImageIcon(ManageSales.class.getResource("/frontEnd/images/icons8_cancel_48px.png")));
				cancelButton.setBounds(1020, 8, 186, 48);
				cancelButton.setPreferredSize(new Dimension(100, 30));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}

		lblManage = new JLabel("Manage wine sales per year.");
		lblManage.setHorizontalAlignment(SwingConstants.LEFT);
		lblManage.setForeground(Color.WHITE);
		lblManage.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 34));
		lblManage.setBounds(394, 86, 513, 31);
		panelBg.add(lblManage);

		btnInsertIncomePer = new JButton("Income per year");
		btnInsertIncomePer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddIncomeYear addIncome = new AddIncomeYear(myWarehouse);
				addIncome.setModal(true);
				addIncome.setVisible(true);
			}
		});
		btnInsertIncomePer.setIcon(new ImageIcon(ManageSales.class.getResource("/frontEnd/images/icons8_stack_of_money_48px.png")));
		btnInsertIncomePer.setIconTextGap(30);
		btnInsertIncomePer.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnInsertIncomePer.setHorizontalAlignment(SwingConstants.LEADING);
		btnInsertIncomePer.setForeground(new Color(255, 255, 240));
		btnInsertIncomePer.setFont(new Font("Consolas", Font.BOLD, 26));
		btnInsertIncomePer.setBorder(new LineBorder(Color.RED, 1, true));
		btnInsertIncomePer.setBackground(Color.BLACK);
		btnInsertIncomePer.setBounds(188, 286, 366, 53);
		panelBg.add(btnInsertIncomePer);

		btnSalesPerYear = new JButton("Sales per year");
		btnSalesPerYear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListSalesYear listSales = new ListSalesYear(myWarehouse);
				listSales.setModal(true);
				listSales.setVisible(true);
			}
		});
		btnSalesPerYear.setIcon(new ImageIcon(ManageSales.class.getResource("/frontEnd/images/icons8_economic_improvement_48px.png")));
		btnSalesPerYear.setIconTextGap(30);
		btnSalesPerYear.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnSalesPerYear.setHorizontalAlignment(SwingConstants.LEADING);
		btnSalesPerYear.setForeground(new Color(255, 255, 240));
		btnSalesPerYear.setFont(new Font("Consolas", Font.BOLD, 26));
		btnSalesPerYear.setBorder(new LineBorder(Color.RED, 1, true));
		btnSalesPerYear.setBackground(Color.BLACK);
		btnSalesPerYear.setBounds(774, 286, 366, 53);
		panelBg.add(btnSalesPerYear);

		lblInsert = new JLabel("Insert:");
		lblInsert.setHorizontalAlignment(SwingConstants.LEFT);
		lblInsert.setForeground(Color.WHITE);
		lblInsert.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblInsert.setBounds(188, 232, 182, 31);
		panelBg.add(lblInsert);

		lblViewTable = new JLabel("View table:");
		lblViewTable.setHorizontalAlignment(SwingConstants.LEFT);
		lblViewTable.setForeground(Color.WHITE);
		lblViewTable.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblViewTable.setBounds(774, 232, 182, 31);
		panelBg.add(lblViewTable);

	}


}