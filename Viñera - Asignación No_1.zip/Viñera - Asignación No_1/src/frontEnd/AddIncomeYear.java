package frontEnd;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import backEnd.Warehouse;
import backEnd.Wine;
import javax.swing.SpinnerNumberModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;

public class AddIncomeYear extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JPanel panelBg;
	private JPanel panel;
	private JLabel lblYear1;
	private JSpinner spn1;
	private JLabel lblAmounts;
	private JSeparator separator;

	private JLabel lblMa;
	private JLabel lblYear2;
	private JLabel lblYear3;
	private JLabel lblYear4;
	private JLabel lblYear5;
	private JLabel lblYear6;
	private JLabel lblYear7;
	private JLabel lblYear8;
	private JLabel lblYear9;
	private JLabel lblYear10;
	private JSpinner spn2;
	private JSpinner spn4;
	private JSpinner spn3;
	private JSpinner spn5;
	private JSpinner spn6;
	private JSpinner spn7;
	private JSpinner spn8;
	private JSpinner spn9;
	private JSpinner spn10;
	private JLabel lblSelectWine;
	private JComboBox cbxWines;

	private Warehouse myWarehouse;
	private Wine myWine;
	private JTextField txtCodeWine;
	private JButton btnSelect;

	/**
	 * Create the dialog.
	 */
	public AddIncomeYear(Warehouse warehouse) {
		this.myWarehouse = warehouse;


		getContentPane().setBackground(new Color(128, 128, 128));
		setBackground(new Color(255, 250, 250));
		setResizable(false);
		setUndecorated(true);
		setBounds(543, 66, 1300, 900);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 1300, 900);
		contentPanel.setBackground(new Color(20, 10, 15));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);

		panelBg = new JPanel();
		panelBg.setBounds(0, 0, 1300, 900);
		contentPanel.add(panelBg);
		panelBg.setBackground(new Color(0, 0, 0));
		panelBg.setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setBounds(0, 817, 1300, 83);
			panelBg.add(buttonPane);
			buttonPane.setBorder(null);
			buttonPane.setLayout(null);
			{
				JButton okButton = new JButton();
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String code = txtCodeWine.getText();
						Wine auxWine = myWarehouse.searchWineByCode(code);

						int [] sales = new int [10];

						sales[0] = Integer.parseInt(spn1.getValue().toString());
						sales[1] = Integer.parseInt(spn2.getValue().toString());
						sales[2] = Integer.parseInt(spn3.getValue().toString());
						sales[3] = Integer.parseInt(spn4.getValue().toString());
						sales[4] = Integer.parseInt(spn5.getValue().toString());
						sales[5] = Integer.parseInt(spn6.getValue().toString());
						sales[6] = Integer.parseInt(spn7.getValue().toString());
						sales[7] = Integer.parseInt(spn8.getValue().toString());
						sales[8] = Integer.parseInt(spn9.getValue().toString());
						sales[9] = Integer.parseInt(spn10.getValue().toString());


						myWarehouse.addSalesWinePerYear(auxWine, sales);
						clean();



					}
				});

				if (myWine == null) {
					okButton.setText("Add");
					okButton.setPressedIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_wine_bottle_48px_1.png")));
					okButton.setRolloverIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_wine_bottle_48px_1.png")));
					okButton.setIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_add_48px_1.png")));
				} 
				else
				{
					okButton.setText("Save");
					okButton.setRolloverIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setPressedIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_save_close_48px.png")));
					okButton.setIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_save_48px_1.png")));
				}



				okButton.setFont(new Font("Consolas", Font.BOLD, 20));
				okButton.setForeground(new Color(255, 255, 255));
				okButton.setOpaque(false);
				okButton.setBackground(new Color(255, 250, 250, 80));
				okButton.setBorder(null);
				okButton.setBounds(778, 8, 186, 48);
				okButton.setPreferredSize(new Dimension(100, 30));
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{

				JButton cancelButton = new JButton("Cancel");
				cancelButton.setRolloverIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setPressedIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setFont(new Font("Consolas", Font.BOLD, 20));
				cancelButton.setForeground(new Color(255, 255, 255));
				cancelButton.setHideActionText(true);
				cancelButton.setBackground(new Color(0, 0, 0));
				cancelButton.setBorder(null);
				cancelButton.setIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_cancel_48px.png")));
				cancelButton.setBounds(1020, 8, 186, 48);
				cancelButton.setPreferredSize(new Dimension(100, 30));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}

		panel = new JPanel();
		panel.setVisible(false);
		panel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		panel.setBackground(Color.BLACK);
		panel.setBounds(125, 294, 1053, 475);
		panelBg.add(panel);
		panel.setLayout(null);

		lblYear1 = new JLabel("1 year:");
		lblYear1.setBounds(40, 39, 182, 31);
		lblYear1.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear1.setForeground(Color.WHITE);
		lblYear1.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		panel.add(lblYear1);

		spn1 = new JSpinner();
		spn1.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spn1.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn1.setBounds(40, 83, 182, 41);
		panel.add(spn1);

		lblYear2 = new JLabel("2 year:");
		lblYear2.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear2.setForeground(Color.WHITE);
		lblYear2.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear2.setBounds(300, 39, 182, 31);
		panel.add(lblYear2);

		lblYear3 = new JLabel("3 year:");
		lblYear3.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear3.setForeground(Color.WHITE);
		lblYear3.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear3.setBounds(581, 39, 182, 31);
		panel.add(lblYear3);

		lblYear4 = new JLabel("4 year:");
		lblYear4.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear4.setForeground(Color.WHITE);
		lblYear4.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear4.setBounds(837, 39, 182, 31);
		panel.add(lblYear4);

		lblYear5 = new JLabel("5 year:");
		lblYear5.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear5.setForeground(Color.WHITE);
		lblYear5.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear5.setBounds(40, 191, 182, 31);
		panel.add(lblYear5);

		lblYear6 = new JLabel("6 year:");
		lblYear6.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear6.setForeground(Color.WHITE);
		lblYear6.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear6.setBounds(300, 191, 182, 31);
		panel.add(lblYear6);

		lblYear7 = new JLabel("7 year:");
		lblYear7.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear7.setForeground(Color.WHITE);
		lblYear7.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear7.setBounds(581, 191, 182, 31);
		panel.add(lblYear7);

		lblYear8 = new JLabel("8 year:");
		lblYear8.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear8.setForeground(Color.WHITE);
		lblYear8.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear8.setBounds(837, 191, 182, 31);
		panel.add(lblYear8);

		lblYear9 = new JLabel("9 year:");
		lblYear9.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear9.setForeground(Color.WHITE);
		lblYear9.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear9.setBounds(40, 347, 182, 31);
		panel.add(lblYear9);

		lblYear10 = new JLabel("10 year:");
		lblYear10.setHorizontalAlignment(SwingConstants.LEFT);
		lblYear10.setForeground(Color.WHITE);
		lblYear10.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblYear10.setBounds(300, 347, 182, 31);
		panel.add(lblYear10);

		spn2 = new JSpinner();
		spn2.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn2.setBounds(300, 83, 182, 41);
		panel.add(spn2);

		spn4 = new JSpinner();
		spn4.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn4.setBounds(837, 83, 182, 41);
		panel.add(spn4);

		spn3 = new JSpinner();
		spn3.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn3.setBounds(581, 83, 182, 41);
		panel.add(spn3);

		spn5 = new JSpinner();
		spn5.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn5.setBounds(40, 235, 182, 41);
		panel.add(spn5);

		spn6 = new JSpinner();
		spn6.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn6.setBounds(300, 235, 182, 41);
		panel.add(spn6);

		spn7 = new JSpinner();
		spn7.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn7.setBounds(581, 235, 182, 41);
		panel.add(spn7);

		spn8 = new JSpinner();
		spn8.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn8.setBounds(837, 235, 182, 41);
		panel.add(spn8);

		spn9 = new JSpinner();
		spn9.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn9.setBounds(40, 391, 182, 41);
		panel.add(spn9);

		spn10 = new JSpinner();
		spn10.setFont(new Font("Consolas", Font.ITALIC, 20));
		spn10.setBounds(300, 391, 182, 41);
		panel.add(spn10);

		lblAmounts = new JLabel("  Income per year:");
		lblAmounts.setOpaque(true);
		lblAmounts.setForeground(Color.WHITE);
		lblAmounts.setFont(new Font("Consolas", Font.BOLD, 26));
		lblAmounts.setBackground(new Color(240, 240, 240, 99));
		lblAmounts.setBounds(125, 239, 1053, 37);
		panelBg.add(lblAmounts);

		separator = new JSeparator();
		separator.setOpaque(true);
		separator.setBorder(new LineBorder(new Color(255, 165, 0), 8));
		separator.setBackground(new Color(255, 165, 0));
		separator.setBounds(125, 273, 1053, 8);
		panelBg.add(separator);

		lblMa = new JLabel("Manage wine sales per year.");
		lblMa.setHorizontalAlignment(SwingConstants.LEFT);
		lblMa.setForeground(Color.WHITE);
		lblMa.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 34));
		lblMa.setBounds(394, 86, 513, 31);
		panelBg.add(lblMa);

		lblSelectWine = new JLabel("- Select wine:");
		lblSelectWine.setHorizontalAlignment(SwingConstants.LEFT);
		lblSelectWine.setForeground(Color.WHITE);
		lblSelectWine.setFont(new Font("Consolas", Font.BOLD | Font.ITALIC, 26));
		lblSelectWine.setBounds(135, 173, 196, 31);
		panelBg.add(lblSelectWine);

		cbxWines = new JComboBox();
		cbxWines.setFont(new Font("Consolas", Font.ITALIC, 20));
		cbxWines.setBounds(343, 173, 312, 31);
		panelBg.add(cbxWines);

		txtCodeWine = new JTextField();
		txtCodeWine.setEditable(false);
		txtCodeWine.setFont(new Font("Consolas", Font.ITALIC, 20));
		txtCodeWine.setColumns(10);
		txtCodeWine.setBounds(712, 173, 220, 31);
		panelBg.add(txtCodeWine);

		btnSelect = new JButton();
		btnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String codeWineSelect = myWarehouse.searchCodeByNameWine(cbxWines.getSelectedItem().toString());
				txtCodeWine.setText(codeWineSelect);
				panel.setVisible(true);
			}
		});
		btnSelect.setIcon(new ImageIcon(AddIncomeYear.class.getResource("/frontEnd/images/icons8_wine_glass_36px.png")));
		btnSelect.setText("Select");
		btnSelect.setPreferredSize(new Dimension(100, 30));
		btnSelect.setForeground(Color.BLACK);
		btnSelect.setFont(new Font("Consolas", Font.BOLD, 20));
		btnSelect.setBorder(null);
		btnSelect.setBackground(new Color(255, 140, 0));
		btnSelect.setActionCommand("OK");
		btnSelect.setBounds(992, 159, 147, 45);
		panelBg.add(btnSelect);

		loadAvailableWines();

	}

	private void clean() {

		spn1.setValue(Integer.parseInt("0"));
		spn2.setValue(Integer.parseInt("0"));
		spn3.setValue(Integer.parseInt("0"));
		spn4.setValue(Integer.parseInt("0"));
		spn5.setValue(Integer.parseInt("0"));
		spn6.setValue(Integer.parseInt("0"));
		spn7.setValue(Integer.parseInt("0"));
		spn8.setValue(Integer.parseInt("0"));
		spn9.setValue(Integer.parseInt("0"));
		spn10.setValue(Integer.parseInt("0"));
		panel.setVisible(false);



	}

	private void loadAvailableWines() {//PARA CARGAR LOS VINOS AL CBXWINES
		cbxWines.removeAllItems();

		for (int i = 0; i < myWarehouse.getAmountWine() ; i++) {
			cbxWines.addItem(new String(myWarehouse.getListWine()[i].getName()));
		}
		cbxWines.insertItemAt(new String("<Select>"), 0);
		cbxWines.setSelectedIndex(0);

	}
}