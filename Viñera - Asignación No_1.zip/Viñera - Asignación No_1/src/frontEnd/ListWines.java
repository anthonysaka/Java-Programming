package frontEnd;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import backEnd.Supplier;
import backEnd.Warehouse;
import backEnd.Wine;

public class ListWines extends JDialog {

	private final JPanel contentPanel = new JPanel();


	private static DefaultTableModel model;
	private JPanel panelBg;
	private JScrollPane scrollPane;
	private static JTable tableWines;
	private static Object[] column;
	private JButton btnModify;
	private JButton btnDelete;
	
	private static Warehouse myWarehouse;
	private String codeWine;
	private String nameWine;



	/**
	 * Create the dialog.
	 */
	public ListWines(Warehouse warehouse) {
		this.myWarehouse = warehouse;
		getContentPane().setBackground(new Color(128, 128, 128));
		setBackground(new Color(255, 250, 250));
		setResizable(false);
		setUndecorated(true);
		setBounds(543, 66, 1300, 900);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 1300, 900);
		contentPanel.setBackground(new Color(20, 10, 15));
		contentPanel.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);

		panelBg = new JPanel();
		panelBg.setBounds(0, 0, 1300, 900);
		contentPanel.add(panelBg);
		panelBg.setBackground(new Color(0, 0, 0));
		panelBg.setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 0, 0));
			buttonPane.setBounds(0, 817, 1300, 83);
			panelBg.add(buttonPane);
			buttonPane.setBorder(null);
			buttonPane.setLayout(null);
			{

				JButton cancelButton = new JButton("Cancel");
				cancelButton.setRolloverIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setPressedIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_2_48px.png")));
				cancelButton.setFont(new Font("Consolas", Font.BOLD, 20));
				cancelButton.setForeground(new Color(255, 255, 255));
				cancelButton.setHideActionText(true);
				cancelButton.setBackground(new Color(0, 0, 0));
				cancelButton.setBorder(null);
				cancelButton.setIcon(new ImageIcon(AddSupplier.class.getResource("/frontEnd/images/icons8_cancel_48px.png")));
				cancelButton.setBounds(1020, 8, 186, 48);
				cancelButton.setPreferredSize(new Dimension(100, 30));
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}

			btnModify = new JButton("Modify");
			btnModify.setAlignmentX(Component.CENTER_ALIGNMENT);
			btnModify.setEnabled(false);
			btnModify.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Wine auxWine = myWarehouse.searchWineByCode(codeWine);
					AddWine wineAdd = new AddWine(myWarehouse, auxWine);
					wineAdd.setModal(true);
					wineAdd.setVisible(true);
				}
			});
			btnModify.setRolloverIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_edit_property_48px.png")));
			btnModify.setPressedIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_edit_property_48px.png")));
			btnModify.setIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_edit_48px.png")));
			btnModify.setPreferredSize(new Dimension(100, 30));
			btnModify.setOpaque(false);
			btnModify.setForeground(Color.WHITE);
			btnModify.setFont(new Font("Consolas", Font.BOLD, 20));
			btnModify.setBorder(null);
			btnModify.setBackground(new Color(255, 250, 250, 80));
			btnModify.setActionCommand("OK");
			btnModify.setBounds(624, 8, 186, 48);
			buttonPane.add(btnModify);

			btnDelete = new JButton("Delete");
			btnDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int option = JOptionPane.showConfirmDialog(null, "Are you sure delete the wine: / "+ codeWine + nameWine, "Delte - WARNING", JOptionPane.WARNING_MESSAGE);
					
					if (option == JOptionPane.OK_OPTION) {
						myWarehouse.deleteWine(codeWine);
						JOptionPane.showMessageDialog(null, "Successfully deleted", "Alert - Did it!", JOptionPane.INFORMATION_MESSAGE);
						loadTableWine();
						btnDelete.setEnabled(false);
						btnModify.setEnabled(false);
					}
				}
			});
			btnDelete.setEnabled(false);
			btnDelete.setRolloverIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_eraser_48px.png")));
			btnDelete.setPressedIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_eraser_48px.png")));
			btnDelete.setIcon(new ImageIcon(ListSuppliers.class.getResource("/frontEnd/images/icons8_delete_forever_48px.png")));
			btnDelete.setPreferredSize(new Dimension(100, 30));
			btnDelete.setOpaque(false);
			btnDelete.setForeground(Color.WHITE);
			btnDelete.setFont(new Font("Consolas", Font.BOLD, 20));
			btnDelete.setBorder(null);
			btnDelete.setBackground(new Color(255, 250, 250, 80));
			btnDelete.setActionCommand("OK");
			btnDelete.setBounds(822, 8, 186, 48);
			buttonPane.add(btnDelete);
		}

		scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 1276, 791);
		panelBg.add(scrollPane);
		
		tableWines = new JTable();
		tableWines.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if (tableWines.getSelectedRow() >= 0) {
					int index = tableWines.getSelectedRow();
					btnDelete.setEnabled(true);
					btnModify.setEnabled(true);
					codeWine = (String) tableWines.getModel().getValueAt(index, 0);
					nameWine = (String) tableWines.getModel().getValueAt(index, 2);
					
				}
				
				
			}
		});
		tableWines.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Code", "Supplier", "Name", "Type", "Vintage year", "Min. Amount", "Max. Amount", "Real. Amount"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Object.class, Object.class, Object.class, Object.class, Integer.class, Object.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		tableWines.getColumnModel().getColumn(0).setResizable(false);
		tableWines.getColumnModel().getColumn(1).setResizable(false);
		tableWines.getColumnModel().getColumn(2).setResizable(false);
		tableWines.getColumnModel().getColumn(3).setResizable(false);
		tableWines.getColumnModel().getColumn(4).setResizable(false);
		tableWines.getColumnModel().getColumn(5).setResizable(false);
		tableWines.getColumnModel().getColumn(6).setResizable(false);
		tableWines.getColumnModel().getColumn(7).setResizable(false);
		scrollPane.setViewportView(tableWines);

		loadTableWine();
	}

	/* FUNCTIONS */
	public static void loadTableWine() {
		model = (DefaultTableModel) tableWines.getModel();
		model.setRowCount(0);
		column = new Object[model.getColumnCount()];

		for (int i = 0; i < myWarehouse.getAmountWine(); i++) {
			column[0] = myWarehouse.getListWine()[i].getCode();
			column[1] = myWarehouse.getListWine()[i].getSupplier().getName();
			column[2] = myWarehouse.getListWine()[i].getName();
			column[3] = myWarehouse.getListWine()[i].getType();
			column[4] = myWarehouse.getListWine()[i].getVintageYear();
			column[5] = myWarehouse.getListWine()[i].getMinAmount();
			column[6] = myWarehouse.getListWine()[i].getMaxAmount();
			column[7] = myWarehouse.getListWine()[i].getRealAmount();
			model.addRow(column);
		}

	}
}
