package backEnd;

public class Main {
	// ***** MAIN *****
	public static void main(String[] args) {
//		
//		Warehouse alma = new Warehouse();
//		Supplier s1 = new Supplier("Juan", "Chile", 29);
//		Wine v1 = new Wine("Carlos Rossie", 1, "tinto", 1950, 10, 50, 2, s1);
//		Wine v2 = new Wine("Juan Rossie", 2, "tinto", 1980, 15, 50, 48, s1);
//		
//		int [] ven = new int[10];
//		for (int i = 0; i < 10; i++) {
//			ven[i] = i+1*10;
//			
//		}
//		v1.setSalesPerYear(ven);
//		v2.setSalesPerYear(ven);
//		alma.addWine(v1);
//		alma.addWine(v2);
//		alma.addSupplier(s1);
//
//		//System.out.println(alma.makeOrden(1));
//		
//		if (alma.makeOrden(2)) {
//			System.out.println("AVISO, Debe hacer pedido del vino.");
//			
//		}
//		else {
//			System.out.println("AVISO, No debe hacer pedido de vino.");
//		}

	}
}