package backEnd;

public class Supplier {
	
	/* ---------- Attributes ---------- */
	
	private String name;
	private String country;
	private int timeDelivery;
	
	/* ---------- Constructor  ---------- */
	
	public Supplier(String name, String country, int timeDelivery) {
		super();
		this.name = name;
		this.country = country;
		this.timeDelivery = timeDelivery;
	}
	
	/* ---------- Gets and Sets  ---------- */
	
	public String getName() {
		return name;
	}

	public String getCountry() {
		return country;
	}

	public int getTimeDelivery() {
		return timeDelivery;
	}
/* ------- */
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setCountry(String country) {
		this.country = country;
	}

	public void setTimeDelivery(int timeDelivery) {
		this.timeDelivery = timeDelivery;
	}



	
	


}
