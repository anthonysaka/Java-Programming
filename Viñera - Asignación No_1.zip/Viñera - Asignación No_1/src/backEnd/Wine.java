package backEnd;

public class Wine {
	
	/* ---------- Attributes ---------- */
	
	public static int generateCode=1;
	private String name;
	private String code;
	private String type;
	private int vintageYear;
	private int minAmount;
	private int maxAmount;
	private int realAmount;
	private int[] salesPerYear;
	private Supplier supplier;
	
	/* ---------- Constructor  ---------- */
	
	public Wine(String name, String code, String type, int vintageYear, int minAmount, int maxAmount, int realAmount, Supplier supplier) {
		super();
		this.name = name;
		this.code = code;
		this.type = type;
		this.vintageYear = vintageYear;
		this.minAmount = minAmount;
		this.maxAmount = maxAmount;
		this.realAmount = realAmount;
		this.supplier = supplier;
		this.salesPerYear = new int[10];
	}
	
	/* ---------- Gets and Sets  ---------- */
	
	public String getName() {
		return name;
	}
	
	public String getCode() {
		return code;
	}
	
	public String getType() {
		return type;
	}

	public int getVintageYear() {
		return vintageYear;
	}

	public int getMinAmount() {
		return minAmount;
	}

	public int getMaxAmount() {
		return maxAmount;
	}

	public int getRealAmount() {
		return realAmount;
	}

	public int[] getSalesPerYear() {
		return salesPerYear;
	}

	public Supplier getSupplier() {
		return supplier;
	}
/* ------- */
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setCodigo(String codigo) {
		this.code = codigo;
	}
	
	public void setType(String type) {
		this.type = type;
	}

	public void setVintageYear(int vintageYear) {
		this.vintageYear = vintageYear;
	}

	public void setMinAmount(int minAmount) {
		this.minAmount = minAmount;
	}

	public void setMaxAmount(int maxAmount) {
		this.maxAmount = maxAmount;
	}

	public void setRealAmount(int realAmount) {
		this.realAmount = realAmount;
	}

	public void setSalesPerYear(int[] salesPerYear) {
		this.salesPerYear = salesPerYear;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	
	/******** Methods - Functions *******/
	
	public boolean average() { //Return True if sales of last year is '>' that average 3 year ago.
		
		int sum =0;
		int i = 0;
		float average=0;
		
		for(i = 6; i < 9; i++) {
			sum+=salesPerYear[i];
		}
		average = (float)sum/3;
		if(average < salesPerYear[9]) {
			return true;
		}
		else {
			return false;
		}
	}

	
	
	


	
	
	

}
