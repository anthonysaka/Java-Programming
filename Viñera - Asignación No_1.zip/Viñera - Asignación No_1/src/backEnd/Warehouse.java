package backEnd;

import java.util.Arrays;

//Controller Class - Clase controladora.
public class Warehouse {

	/* ---------- Attributes ---------- */

	private Wine[] listWine;
	private Supplier[] listSupplier;
	private int amountWine;
	private int amountSupplier;


	/* ---------- Constructor  --------  no se le paso parametro porque es la controladora OJO con esto tengo que analizar-- */

	public Warehouse() {
		amountSupplier = 0;
		amountWine = 0;
		listSupplier = new Supplier[50]; //Arreglo estactico
		listWine = new Wine[50];  // Arreglo estactico
	}


	/* ---------- Gets and Sets  ---------- */

	public Wine[] getListWine() {
		return listWine;
	}

	public Supplier[] getListSupplier() {
		return listSupplier;
	}

	public int getAmountWine() {
		return amountWine;
	}

	public int getAmountSupplier() {
		return amountSupplier;
	}
	/* ------- */

	public void setListWine(Wine[] listWine) {
		this.listWine = listWine;
	}

	public void setListSupplier(Supplier[] listSupplier) {
		this.listSupplier = listSupplier;
	}

	public void setAmountWine(int amountWine) {
		this.amountWine = amountWine;
	}

	public void setAmountSupplier(int amountSupplier) {
		this.amountSupplier = amountSupplier;
	}


	/******** Methods - Functions *******/

	private Wine searchByCode(String code) {

		Wine auxWine = null;
		boolean found = false;
		int i = 0;

		while (!found && (i < amountWine)) {
			if(listWine [i].getCode().equalsIgnoreCase(code)) {
				found = true;
				auxWine = listWine [i];
			}

			i++;
		}
	    return auxWine;
	}

	public boolean makeOrden(String code) {

		boolean make = false;
		Wine auxWine = null;
		auxWine = searchByCode(code);

		if(auxWine != null) {
			if((auxWine.getRealAmount() < auxWine.getMinAmount()) && (auxWine.getSupplier().getTimeDelivery() < 30 && auxWine.average())) {
				make = true;
			}
		}
		return make;
	}

	public void addWine(Wine wine) {
		listWine[amountWine] = wine;
		amountWine++;
		Wine.generateCode++;
	}


	public void addSupplier(Supplier suppli) {
		listSupplier[amountSupplier] = suppli;
		amountSupplier++;
	}


	public void deleteSupplier(String nameSuppli) {
		int auxSuppli = searchIndexSupplierByName(nameSuppli); //Guarda la posicion del suplidor, retornado por la funcion searchIndexSupplierByName.
		if (auxSuppli >= 0) {
			while (auxSuppli < (amountSupplier - 1)) {
				listSupplier[auxSuppli] = listSupplier[auxSuppli+1];
				auxSuppli++;
			}
			
		amountSupplier--;
		}

	}

	public void deleteWine(String codeWine) {
		int auxWine = searchIndexWineByCode(codeWine); //Guarda la posicion del vino, retornado por la funcion searchIndexWineByCode.
		if (auxWine >= 0) {
			while (auxWine < (amountWine - 1)) {
				listWine[auxWine] = listWine[auxWine+1];
				auxWine++;
			}
			
		amountWine--;
		}

	}

	public int searchIndexSupplierByName(String nameSuppli) {
		int auxSuppli = -1;
		boolean found = false;
		int i = 0;

		while (!found && (i < amountSupplier)) {
			if(listSupplier[i].getName().equalsIgnoreCase(nameSuppli)) {
				found = true;
				auxSuppli = i;
			}

			i++;
		}
	    return auxSuppli; //Retorna el valor del index, o sea la posicion del suplidor.
	}
	
	public int searchIndexWineByCode(String codeWine) {
		int auxWine = -1;
		boolean found = false;
		int i = 0;

		while (!found && (i < amountWine)) {
			if(listWine[i].getCode().equalsIgnoreCase(codeWine)) {
				found = true;
				auxWine = i;
			}

			i++;
		}
	    return auxWine; //Retorna el valor del index, o sea la posicion del vino.
	}

	public Supplier searchSupplierByName(String nameSuppli) {
		Supplier auxSuppli = null;
		boolean found = false;
		int i = 0;

		while (!found && i < amountSupplier) {
			if(listSupplier [i].getName().equalsIgnoreCase(nameSuppli)) {
				found = true;
				auxSuppli = listSupplier[i];
			}

			i++;
		}
	    return auxSuppli; //Retorna el suplidor del nombre encontrado
	}
	
	public Wine searchWineByCode(String codeWine) {
		Wine auxWine = null;
		boolean found = false;
		int i = 0;

		while (!found && i < amountWine) {
			if(listWine [i].getCode().equalsIgnoreCase(codeWine)) {
				found = true;
				auxWine = listWine[i];
			}

			i++;
		}
	    return auxWine; //Retorna el vino del codigo encontrado
	}

	public String searchCodeByNameWine(String nameWine) {
		String auxWine = null;
		boolean found = false;
		int i = 0;

		while (!found && i < amountWine) {
			if(listWine [i].getName().equalsIgnoreCase(nameWine)) {
				found = true;
				auxWine = listWine[i].getCode();
			}

			i++;
		}
	    return auxWine; //Retorna el codigo del vino encontrado.
	}

	public void updateSuppliers(Supplier mySuppli) {
		int index = searchIndexSupplierByName(mySuppli.getName());
		listSupplier[index]= mySuppli;
		
	}
	
	public void updateWines(Wine myWine) {
		int index = searchIndexWineByCode(myWine.getCode());
		listWine[index]=myWine;
		
	}


	public void addSalesWinePerYear(Wine auxWine, int[] sales) {
		
		auxWine.setSalesPerYear(sales);
		
	}


}
